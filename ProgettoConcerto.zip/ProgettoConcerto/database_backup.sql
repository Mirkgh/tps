-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2026 at 08:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prenotazioni_concerti`
--

-- --------------------------------------------------------

--
-- Table structure for table `concerto`
--

CREATE TABLE `concerto` (
  `id_concerto` int(11) NOT NULL,
  `titolo` varchar(100) NOT NULL,
  `artista` varchar(50) NOT NULL,
  `location` varchar(250) NOT NULL,
  `data_evento` date NOT NULL,
  `posti_totali` int(11) NOT NULL,
  `posti_disponibili` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `concerto`
--

INSERT INTO `concerto` (`id_concerto`, `titolo`, `artista`, `location`, `data_evento`, `posti_totali`, `posti_disponibili`) VALUES
(1, 'Circus Maximus', 'Travis Scott', 'Assago Forum MI', '2025-07-10', 30000, 29996),
(3, 'HellWatt Festival', 'Kanye West', 'Ippodromo La Maura', '2025-09-12', 60000, 60000),
(6, 'Northside Melodies', 'Glocky', 'Arena', '2026-05-12', 100, 9998),
(11, 'Lady Gaga SuperStar', 'Lady Gaga', 'Unipol', '2026-05-13', 100000, 100000);

-- --------------------------------------------------------

--
-- Table structure for table `prenotazione`
--

CREATE TABLE `prenotazione` (
  `id_prenotazione` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL,
  `id_concerto` int(11) NOT NULL,
  `data_prenotazione` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prenotazione`
--

INSERT INTO `prenotazione` (`id_prenotazione`, `id_utente`, `id_concerto`, `data_prenotazione`) VALUES
(30, 1, 6, '2026-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `utente`
--

CREATE TABLE `utente` (
  `id_utente` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utente`
--

INSERT INTO `utente` (`id_utente`, `nome`, `email`) VALUES
(1, 'Mirko Marcis', 'mirko.marcis@gmail.com'),
(2, 'Fabio Rossi', 'fabio.rossi@gmail.com'),
(3, 'Luca Verdi', 'luca.verdi@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `concerto`
--
ALTER TABLE `concerto`
  ADD PRIMARY KEY (`id_concerto`);

--
-- Indexes for table `prenotazione`
--
ALTER TABLE `prenotazione`
  ADD PRIMARY KEY (`id_prenotazione`),
  ADD KEY `id_utente` (`id_utente`),
  ADD KEY `id_concerto` (`id_concerto`);

--
-- Indexes for table `utente`
--
ALTER TABLE `utente`
  ADD PRIMARY KEY (`id_utente`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `concerto`
--
ALTER TABLE `concerto`
  MODIFY `id_concerto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `prenotazione`
--
ALTER TABLE `prenotazione`
  MODIFY `id_prenotazione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `utente`
--
ALTER TABLE `utente`
  MODIFY `id_utente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `prenotazione`
--
ALTER TABLE `prenotazione`
  ADD CONSTRAINT `prenotazione_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utente` (`id_utente`),
  ADD CONSTRAINT `prenotazione_ibfk_2` FOREIGN KEY (`id_concerto`) REFERENCES `concerto` (`id_concerto`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
