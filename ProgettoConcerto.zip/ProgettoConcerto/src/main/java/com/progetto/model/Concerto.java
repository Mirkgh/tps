package com.progetto.model;

public class Concerto {
    // Variabili che rispecchiano le colonne della tabella concerto
    private int id_concerto;
    private String titolo, artista, location, data_evento;
    private int posti_disponibili;

    // Costruttore vuoto per Gson
    public Concerto() {}

    // Costruttore completo
    public Concerto(int id_concerto, String titolo, String artista, String location, String data_evento, int posti_disponibili) {
        this.id_concerto = id_concerto;
        this.titolo = titolo;
        this.artista = artista;
        this.location = location;
        this.data_evento = data_evento;
        this.posti_disponibili = posti_disponibili;
    }

    // Getter per la conversione in JSON
    public int getId_concerto() { return id_concerto; }
    public String getTitolo() { return titolo; }
    public String getArtista() { return artista; }
    public String getLocation() { return location; }
    public String getData_evento() { return data_evento; }
    public int getPosti_disponibili() { return posti_disponibili; }
}