package com.progetto.model;
public class Prenotazione {
    private int id_prenotazione, id_utente, id_concerto;
    public Prenotazione(int id_prenotazione, int id_utente, int id_concerto) {
        this.id_prenotazione = id_prenotazione;
        this.id_utente = id_utente;
        this.id_concerto = id_concerto;
    }
}