package com.progetto.model;
public class Utente {
    private int id_utente;
    private String nome;
    private String email;
    // Costruttore e Getter per GSON
    public Utente(int id_utente, String nome, String email) {
        this.id_utente = id_utente; this.nome = nome; this.email = email;
    }
}