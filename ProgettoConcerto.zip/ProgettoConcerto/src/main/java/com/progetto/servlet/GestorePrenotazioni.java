package com.progetto.servlet;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.progetto.db.DBManager;
import com.progetto.model.Concerto;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/api/prenota")
public class GestorePrenotazioni extends HttpServlet {
    
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        PrintWriter out = response.getWriter();

        try (Connection conn = DBManager.getConnection()) {
            // AZIONE 1: Lista prenotazioni per Admin (tutte) o per Utente (mie)
            if ("lista_prenotazioni".equals(action)) {
                String sql = "SELECT p.id_prenotazione, c.titolo, u.nome FROM prenotazione p " +
                             "JOIN concerto c ON p.id_concerto = c.id_concerto " +
                             "JOIN utente u ON p.id_utente = u.id_utente";
                ResultSet rs = conn.createStatement().executeQuery(sql);
                JsonArray jArray = new JsonArray();
                while(rs.next()){
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id", rs.getInt("id_prenotazione"));
                    obj.addProperty("concerto", rs.getString("titolo"));
                    obj.addProperty("utente", rs.getString("nome"));
                    jArray.add(obj);
                }
                out.print(gson.toJson(jArray));
            } else if ("mie_prenotazioni".equals(action)) {
                int idU = Integer.parseInt(request.getParameter("id_utente"));
                String sql = "SELECT p.id_prenotazione, c.titolo, c.artista, c.location, c.data_evento " +
                             "FROM prenotazione p JOIN concerto c ON p.id_concerto = c.id_concerto WHERE p.id_utente = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, idU);
                ResultSet rs = ps.executeQuery();
                JsonArray jArray = new JsonArray();
                while(rs.next()){
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_p", rs.getInt("id_prenotazione"));
                    obj.addProperty("t", rs.getString("titolo"));
                    obj.addProperty("a", rs.getString("artista"));
                    obj.addProperty("info", rs.getString("location") + " " + rs.getString("data_evento"));
                    jArray.add(obj);
                }
                out.print(gson.toJson(jArray));
            } else {
                // AZIONE DEFAULT: Lista concerti
                List<Concerto> lista = new ArrayList<>();
                ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM concerto ORDER BY id_concerto DESC");
                while (rs.next()) {
                    lista.add(new Concerto(rs.getInt("id_concerto"), rs.getString("titolo"), rs.getString("artista"), rs.getString("location"), rs.getString("data_evento"), rs.getInt("posti_disponibili")));
                }
                out.print(gson.toJson(lista));
            }
        } catch (Exception e) { e.printStackTrace(); response.setStatus(500); }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try (Connection conn = DBManager.getConnection()) {
            if ("aggiungi_concerto".equals(action)) {
                Concerto c = gson.fromJson(request.getReader(), Concerto.class);
                String sql = "INSERT INTO concerto (titolo, artista, location, data_evento, posti_totali, posti_disponibili) VALUES (?,?,?,?,?,?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, c.getTitolo()); ps.setString(2, c.getArtista()); ps.setString(3, c.getLocation());
                ps.setString(4, c.getData_evento()); ps.setInt(5, c.getPosti_disponibili()); ps.setInt(6, c.getPosti_disponibili());
                ps.executeUpdate();
            } else {
                // PRENOTAZIONE UTENTE
                JsonObject data = gson.fromJson(request.getReader(), JsonObject.class);
                int idC = data.get("id_concerto").getAsInt();
                int idU = data.get("id_utente").getAsInt();
                conn.setAutoCommit(false);
                try {
                    PreparedStatement ps1 = conn.prepareStatement("INSERT INTO prenotazione (id_utente, id_concerto, data_prenotazione) VALUES (?,?, NOW())");
                    ps1.setInt(1, idU); ps1.setInt(2, idC); ps1.executeUpdate();
                    PreparedStatement ps2 = conn.prepareStatement("UPDATE concerto SET posti_disponibili = posti_disponibili - 1 WHERE id_concerto = ? AND posti_disponibili > 0");
                    ps2.setInt(1, idC);
                    if (ps2.executeUpdate() == 0) throw new SQLException();
                    conn.commit();
                } catch (Exception e) { conn.rollback(); throw e; }
            }
            response.getWriter().print("{\"status\":\"success\"}");
        } catch (Exception e) { e.printStackTrace(); response.setStatus(500); }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DBManager.getConnection()) {
            Concerto c = gson.fromJson(request.getReader(), Concerto.class);
            String sql = "UPDATE concerto SET titolo=?, artista=?, location=?, data_evento=?, posti_totali=?, posti_disponibili=? WHERE id_concerto=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getTitolo()); ps.setString(2, c.getArtista()); ps.setString(3, c.getLocation());
            ps.setString(4, c.getData_evento()); ps.setInt(5, c.getPosti_disponibili()); ps.setInt(6, c.getPosti_disponibili());
            ps.setInt(7, c.getId_concerto());
            ps.executeUpdate();
            response.getWriter().print("{\"status\":\"success\"}");
        } catch (Exception e) { response.setStatus(500); }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        int id = Integer.parseInt(request.getParameter("id"));
        try (Connection conn = DBManager.getConnection()) {
            conn.setAutoCommit(false);
            try {
                if ("disdici".equals(action)) {
                    // Recupero id concerto per ridare il posto
                    PreparedStatement psG = conn.prepareStatement("SELECT id_concerto FROM prenotazione WHERE id_prenotazione = ?");
                    psG.setInt(1, id); ResultSet rs = psG.executeQuery();
                    if(rs.next()){
                        int idC = rs.getInt("id_concerto");
                        conn.createStatement().executeUpdate("DELETE FROM prenotazione WHERE id_prenotazione = " + id);
                        conn.createStatement().executeUpdate("UPDATE concerto SET posti_disponibili = posti_disponibili + 1 WHERE id_concerto = " + idC);
                    }
                } else {
                    // Admin elimina concerto
                    conn.createStatement().executeUpdate("DELETE FROM prenotazione WHERE id_concerto = " + id);
                    conn.createStatement().executeUpdate("DELETE FROM concerto WHERE id_concerto = " + id);
                }
                conn.commit();
                response.getWriter().print("{\"status\":\"success\"}");
            } catch (Exception e) { conn.rollback(); throw e; }
        } catch (Exception e) { response.setStatus(500); }
    }
}